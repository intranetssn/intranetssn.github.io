#include<stdio.h>
char a[30][30];
char reg[6],add[30][2];	
int n;

int isop(char a)
{
	switch(a)
 {
		case '+':
		case '-':
		case '*':
		case '/':return 1;
		default:return 0;
	}
}
int findop(char a)
{
	switch(a)
 {
		case '+':printf("ADD ");break;
		case '-':printf("SUB ");break;
		case '*':printf("MUL ");break;
		case '/':printf("DIV ");break;
	}
}
void comp(int i)
{
	int i1,ind=-1;
	for(i1=0;i1<6;i1++)
	{	
		if(reg[i1]==a[i][2])
			ind=i1;
	}
	if(ind==-1)	
	{
		for(i1=0;i1<6;i1++)
		{		
			if(reg[i1]=='0')
			{
				ind=i1;
				reg[ind]=a[i][2];
				break;
			}
		}
	}
	printf("MOV %c,%c\n",a[i][2],ind+'A');
	findop(a[i][3]);
 if(isdigit(a[i][4]))
  printf("#%c,%c\n",a[i][4],ind+'A');
 else
	printf("%c,%c\n",a[i][4],ind+'A');
	printf("MOV %c,%c\n",i1+'A',a[i][0]);
	reg[i1]=a[i][0];	
}
void assign(int i)
{
	if(isdigit(a[i][2]))
	{
		printf("MOV #%c,%c\n",a[i][2],a[i][0]);
	}
	else
	{
		int inr=-1;
		for(int i1=0;i1<6;i1++)
		{
			if(reg[i1]==a[i][2])
			{
				inr=i1;
				break;
			}				
		}
		if(inr==-1)
		{	for(int i1=0;i1<6;i1++)
				{
					if(reg[i1]=='0')
					{
						inr=i1;
						break;
					}	
				}
			printf("MOV %c,%c\n",a[i][2],inr+'A');				
		}
		printf("MOV %c,%c\n",'A'+inr,a[i][0]);
		reg[inr]=a[i][0];
	}
}
void ifcondn(int i)
{
	int j,flag=-1;
	for(j=0;j<6;j++)
	{
		if(reg[j]==a[i][3])
		{
			flag=j;
			break;
		}
	}
	if(flag==-1)
	{	
		for(j=0;j<6;j++)
		{
			if(reg[j]=='0')
			{
				printf("MOV %c,%c\n",a[i][3],j+'A');
				reg[j]=a[i][3];
				break;
			}
		}
	}
	if(isdigit(a[i][3]))
		printf("CMP %c,#%c",j+'A',a[i][5]);
	else
		printf("CMP %c,%c",j+'A',a[i][5]);	
	if(a[i][4]=='<')
		printf("\nJL");
	else if(a[i][4]=='>')
		printf("\nJG");
	if(a[i][5]=='=')
		printf("E");
	for(j=0;a[i][j+1]!='\0';j++);
	printf(" %c",a[i][j]);
}
void uncondn(int i)
{
	printf("\nJMP %c\n",a[i][strlen(a[i])-1]);
}
int main()
{
	for(int i=0;i<6;i++)
		reg[i]='0';
	printf("Number of TAC statements:");
	scanf("%d",&n);
	printf("Enter TAC statements:\n");	
	for(int i=0;i<n;i++)
	{	
		printf("%d:",i);
		scanf("%s",a[i]);
	}	
	printf("\nTarget Code:\n");
	for(int i=0;i<n;i++)
	{
		//Line By Line
		if(isop(a[i][3]))
			comp(i);
		else if(a[i][3]=='\0')
			assign(i);		
		else if(strstr(a[i],"if"))
				ifcondn(i);
		else if(strstr(a[i],"goto"))
			uncondn(i);	
	}
	printf("\nRegister:\n");
	for(int i=0;i<6;i++)
		printf("%c:%c\n",i+'A',reg[i]);
}
