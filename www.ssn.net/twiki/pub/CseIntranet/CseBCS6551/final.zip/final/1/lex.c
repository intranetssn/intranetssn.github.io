#include<stdio.h>
#include<ctype.h>
void main()
{
    char ch,arioperators[]="+-*/%=",logoperators[]="&|!",lexmes[]="=,>,<",special[]="{}";
    FILE *fp;
    int i,j,flag=0;
    fp = fopen("a.txt","r");
    if(fp==NULL)
    {
        printf("File not found");
        exit(0);
    }
    else if(fp!=NULL)
    {
        while((ch = fgetc(fp)) != EOF)
        {
            if(ch =='\n')
            {
                printf("\n");
            }
             if(isspace(ch))
            {
                printf(" ");
            }
             if(ch =='\t')
            {
                printf("\t");
            }

                //ARITHMETIC OPERATORS
            for(i=0;i<=5;i++)
            {
                if(ch ==arioperators[i])
                {
                    switch(ch)
                    {
                        case '+':printf("PLUS");
                                 printf(" ");
                                break;
                        case '-':printf("MINUS");
                                printf(" ");
                                 break;
                        case '*':printf("STAR");
                                printf(" ");
                                 break;
                        case '%':printf("MODULO");
                                printf(" ");
                                 break;

                    }
                }
            }

            //LOGICAL OPERATORS
            for(i=0;i<=3;i++)
            {
                if(ch == logoperators[i])
                {
                    switch(ch)\
                    {
                        case '&':ch = fgetc(fp);
                                 if(ch =='&')
                                 {
                                     printf("AND");
                                     printf(" ");
                                 }
                                 break;
                        case '|':ch = fgetc(fp);
                                 if(ch == '|')
                                 {
                                     printf("OR");
                                     printf(" ");
                                 }
                                 break;
                        case '!':printf("NOT");
                                printf(" ");
                                 break;
                    }
                }
            }



             if(isalpha(ch))
            {
            switch(ch)
            {
              case 'f':ch = fgetc(fp);
                        if(ch=='l')
                        {
                            ch = fgetc(fp);
                            if(ch=='o')
                            {
                                ch = fgetc(fp);
                                if(ch=='a')
                                {
                                    ch = fgetc(fp);
                                    {
                                        if(ch=='t')
                                        {
                                            printf("KW");
                                            printf(" ");
                                            ch = fgetc(fp);
                                            if(isspace(ch))
                                            {
                                                printf(" ");
                                            }
                                            ch = fgetc(fp);
                                            if(isalpha(ch))
                                            {
                                                printf("ID");
                                                printf(" ");
                                                while(ch !='=')
                                                {
                                                    ch = fgetc(fp);
                                                    if(ch==';')
                                                    {
                                                        printf("SP");
                                                        break;
                                                    }

                                                }

                                            }
                                            
                                            if(ch=='=')
                                            {
                                                printf("ASSIGN");
                                                printf(" ");
                                            }
                                            ch = fgetc(fp);
                                            if(isdigit(ch))
                                            {
                                                printf("FLOATCONST");
                                                printf(" ");
                                                while(ch !=';')
                                                {
                                                    ch = fgetc(fp);
                                                    if(ch==';')
                                                    {
                                                        printf("SP");
                                                    }
                                                }

                                            }
                                else if(isalpha(ch))
                                    {
                                     printf("ID");
                                     printf(" ");
                                     while(isalpha(ch))
                                     {
                                         ch = fgetc(fp);
                                     }
                            for(i=0;i<=5;i++)
                            {
                            if(ch ==arioperators[i])
                            {
                            switch(ch)
                            {
                                case '+':printf("PLUS");
                                        printf(" ");
                                        break;
                                case '-':printf("MINUS");
                                        printf(" ");
                                        break;
                                case '*':printf("STAR");
                                        printf(" ");
                                        break;
                                case '%':printf("MODULO");
                                        printf(" ");
                                        break;

                        }
                        }
                        }
                                ch = fgetc(fp);
                                if(isalpha(ch))
                                {
                                    printf("ID");
                                    printf(" ");
                                    while(ch!=';')
                                    {
                                        ch = fgetc(fp);
                                        if(ch==';')
                                        {
                                            printf("SP");
                                            break;
                                        }
                                    }
                                }

                                 }
                                        }
                                    }
                                }
                            }
                        }
                        else if(ch=='o')
                        {
                            ch = fgetc(fp);
                            if(ch=='r')
                            {
                                printf("FN");
                                while(ch !='\n')
                                {
                                    ch = fgetc(fp);
                                }
                            }
                        }
                        break;

            case 'w':ch = fgetc(fp);
                    if(ch=='h')
                    {
                        ch = fgetc(fp);
                        if(ch=='i')
                        {
                            ch = fgetc(fp);
                            if(ch=='l')
                            {
                                ch = fgetc(fp);
                                if(ch=='e')
                                {
                                    printf("FN");
                                    printf(" ");
                                    while(ch !='\n')
                                    {
                                        ch = fgetc(fp);

                                    }
                                }
                            }
                        }
                    }

            case 'i':ch = fgetc(fp);
                     if(ch=='n')
                     {
                         ch = fgetc(fp);
                         if(ch=='t')
                         {
                             printf("KW");
                             printf(" ");
                             ch = fgetc(fp);
                             if(isspace(ch))
                             {
                                 printf(" ");
                             }
                             ch = fgetc(fp);
                             if(isalpha(ch))
                             {
                                 printf("ID");
                                 printf(" ");
                                 while(ch!='=')
                                 {
                                     ch = fgetc(fp);
                                      if(ch==';')
                                    {
                                     printf("SP");
                                     break;
                                    }
                                 }
                                 if(ch=='=')
                                 {
                                     printf("ASSIGN");
                                     printf(" ");
                                 }

                                 ch = fgetc(fp);
                                 if(isdigit(ch))
                                 {
                                     printf("NUMCONST");
                                     printf(" ");
                                     while(ch !=';')
                                     {
                                         ch =fgetc(fp);
                                         if(ch==';')
                                         {
                                             printf("SP");
                                             break;
                                         }
                                     }

                                 }
                                 else if(isalpha(ch))
                                 {
                                     printf("ID");
                                     printf(" ");
                                     while(isalpha(ch))
                                     {
                                         ch = fgetc(fp);
                                     }
                            for(i=0;i<=5;i++)
                            {
                            if(ch ==arioperators[i])
                            {
                            switch(ch)
                            {
                                case '+':printf("PLUS");
                                        printf(" ");
                                        break;
                                case '-':printf("MINUS");
                                        printf(" ");
                                        break;
                                case '*':printf("STAR");
                                        printf(" ");
                                        break;
                                case '%':printf("MODULO");
                                        printf(" ");
                                        break;

                        }
                        }
                        }
                                ch = fgetc(fp);
                                if(isalpha(ch))
                                {
                                    printf("ID");
                                    printf(" ");
                                    while(ch!=';')
                                    {
                                        ch = fgetc(fp);
                                        if(ch==';')
                                        {
                                            printf("SP");
                                            break;
                                        }
                                    }
                                }

                                 }
                             }
                         }

                     }
                     else if(ch =='f')
                          {
                              printf("KW");
                              printf(" ");
                              ch = fgetc(fp);
                              if(ch =='(')
                              {
                                  printf("SP");
                                  printf(" ");
                                  while(ch !=')')
                                  {
                                      ch = fgetc(fp);
                                      if(isalpha(ch))
                                      {

                                          while(isalpha(ch))
                                          {
                                              ch = fgetc(fp);
                                          }
                                      }
                                      printf("ID");
                                      printf(" ");
                                      for(i=0;i<=6;i++)
                                      {
                                         if(ch==lexmes[i])
                                        {
                                          printf("RELOP");
                                          printf(" ");
                                        }
                                      }

                                      if(isspace(ch))
                                      {
                                          printf(" ");
                                      }
                                  }
                                  printf("SP");
                                  printf(" ");
                              }

                          }
                     break;

            case 'e':ch = fgetc(fp);
                         if(ch=='l')
                         {
                             ch = fgetc(fp);
                             if(ch=='s')
                             {
                                 ch = fgetc(fp);
                                 if(ch=='e')
                                 {
                                     ch = fgetc(fp);
                                     if(isspace(ch))
                                     {
                                         ch = fgetc(fp);
                                         if(ch=='i')
                                         {
                                             ch = fgetc(fp);
                                             if(ch=='f')
                                             {
                                                 printf("KW");
                                                 printf(" ");
                                                 ch =fgetc(fp);
                                                 if(ch=='(')
                                                 {
                                                     printf("SP");
                                                     printf(" ");
                                                     while(ch!=')')
                                                     {
                                                         ch = fgetc(fp);
                                                         if(isalpha(ch))
                                                         {
                                                             while(isalnum(ch))
                                                             {
                                                                 ch = fgetc(fp);
                                                             }
                                                         }
                                                         printf("ID");
                                                         printf(" ");
                                                          if(isspace(ch))
                                                         {
                                                             printf(" ");
                                                         }
                                                         for(i=0;i<=6;i++)
                                                         {
                                                             if(ch==lexmes[i])
                                                             {
                                                                 printf("RELOP");
                                                                 printf(" ");
                                                             }
                                                         }
                                                     }
                                                     printf("SP");
                                                     printf(" ");
                                                 }
                                             }
                                         }
                                         else
                                         {
                                             printf("KW");
                                             printf(" ");
                                             printf("\n");
                                         }
                                     }
                                 }

                             }
                         }
                            break;
            case 'r':ch = fgetc(fp);
                        if(ch=='e')
                        {
                            ch = fgetc(fp);
                            if(ch=='a')
                            {
                                ch = fgetc(fp);
                                if(ch=='l')
                                {
                                    printf("KW");
                                    printf(" ");
                                    ch = fgetc(fp);
                                    if(isspace(ch))
                                    {
                                        printf(" ");
                                    }
                                    ch = fgetc(fp);
                                    if(isalpha(ch))
                                    {
                                        printf("ID");
                                        printf(" ");
                                while(ch!='=')
                                 {
                                     ch = fgetc(fp);
                                      if(ch==';')
                                    {
                                     printf("SP");
                                     break;
                                    }
                                 }
                                 if(ch=='=')
                                 {
                                     printf("ASSIGN");
                                     printf(" ");
                                 }
                                 ch = fgetc(fp);
                                 if(isdigit(ch))
                                 {
                                     printf("EXPCONST");
                                     printf(" ");
                                     while(ch !=';')
                                     {
                                         ch = fgetc(fp);
                                         if(ch==';')
                                         {
                                             printf("SP");
                                             break;
                                         }
                                     }
                                 }
                                 else if(isalpha(ch))
                                 {
                                     printf("ID");
                                     printf(" ");
                                     while(isalpha(ch))
                                     {
                                         ch = fgetc(fp);
                                     }
                            for(i=0;i<=5;i++)
                            {
                            if(ch ==arioperators[i])
                            {
                            switch(ch)
                            {
                                case '+':printf("PLUS");
                                        printf(" ");
                                        break;
                                case '-':printf("MINUS");
                                        printf(" ");
                                        break;
                                case '*':printf("STAR");
                                        printf(" ");
                                        break;
                                case '%':printf("MODULO");
                                        printf(" ");
                                        break;

                        }
                        }
                        }
                                ch = fgetc(fp);
                                if(isalpha(ch))
                                {
                                    printf("ID");
                                    printf(" ");
                                    while(ch!=';')
                                    {
                                        ch = fgetc(fp);
                                        if(ch==';')
                                        {
                                            printf("SP");
                                            break;
                                        }
                                    }
                                }

                                 }



                                    }
                                }
                            }
                        }
                        break;
            case 'p':ch = fgetc(fp);
                          if(ch=='r')
                          {
                              ch = fgetc(fp);
                              if(ch=='i')
                              {
                                  ch = fgetc(fp);
                                  if(ch=='n')
                                  {
                                      ch = fgetc(fp);
                                      if(ch=='t')
                                      {
                                          ch = fgetc(fp);
                                          if(ch=='f')
                                          {
                                              printf("FN");
                                              printf(" ");
                                          }
                                      }
                                  }
                              }
                          }
                          while(ch !='\n')
                          {
                              ch = fgetc(fp);
                          }
                          printf("\n");
                          break;
            case 's':ch = fgetc(fp);
                          if(ch=='c')
                          {
                              ch = fgetc(fp);
                              if(ch=='a')
                              {
                                  ch = fgetc(fp);
                                  if(ch=='n')
                                  {
                                      ch = fgetc(fp);
                                      if(ch=='f')
                                      {
                                          printf("FN");
                                          printf(" ");
                                      }
                                  }
                              }
                          }
                          while(ch !='\n')
                          {
                              ch = fgetc(fp);
                          }
                          printf("\n");
                          break;

                case 'm':ch=fgetc(fp);
                         if(ch=='a')
                         {
                             ch = fgetc(fp);
                             if(ch=='i')
                             {
                                 ch = fgetc(fp);
                                 if(ch=='n');
                                 {
                                     ch = fgetc(fp);
                                     if(ch=='(')
                                     {
                                         ch = fgetc(fp);
                                         if(ch ==')')
                                         {
                                             printf("FN");
                                             printf(" ");
                                         }
                                     }
                                     else
                                     {
                                         printf("KW");
                                         printf(" ");
                                     }

                                 }
                             }
                         }
                         while(ch!='\n')
                         {
                             ch = fgetc(fp);
                         }
                         printf("\n");
                         break;



            default:printf("ID");
                    printf(" ");
                    while(ch !='=')
                    {
                        ch = fgetc(fp);
                    }
                    if(ch=='=')
                    {
                        printf("ASSIGN");
                        printf(" ");
                    }
                    ch = fgetc(fp);
                    if(isalpha(ch))
                    {
                        printf("ID");
                        printf(" ");
                        while(isalpha(ch))
                        {
                            ch = fgetc(fp);
                        }
                        for(i=0;i<=5;i++)
                            {
                            if(ch ==arioperators[i])
                            {
                            switch(ch)
                            {
                                case '+':printf("PLUS");
                                        printf(" ");
                                        break;
                                case '-':printf("MINUS");
                                        printf(" ");
                                        break;
                                case '*':printf("STAR");
                                        printf(" ");
                                        break;
                                case '%':printf("MODULO");
                                        printf(" ");
                                        break;

                        }
                        }
                        }
                        ch = fgetc(fp);
                                if(isalpha(ch))
                                {
                                    printf("ID");
                                    printf(" ");
                                    while(ch!=';')
                                    {
                                        ch = fgetc(fp);
                                        if(ch==';')
                                        {
                                            printf("SP");
                                            break;
                                        }
                                    }
                                }

                    }
            }//end of switch
        }
        if(ch == '/')//for comments
            {

                ch = fgetc(fp);
                if(ch == '/')
                {
                    printf("SLC");
                    printf(" ");
		    printf("\n");
                    while(ch !='\n')
                        {
                            ch = fgetc(fp);
                        }
                }
                else if(ch == '*')
                {
                    printf("Start of MLC");
                    printf(" ");
                    while(ch !='*')
                    {
                        ch = fgetc(fp);
                        printf(" ");
			if(ch == '\n')
			{
			 printf("\n");
			}
                    }
                   while(ch !='/')
                   {
                       ch = fgetc(fp);
                       printf(" ");
                   }
                   printf("END OF MLC");
                   printf(" ");

                }
                else
                {
                    printf("DIVIDE");
                    printf(" ");
                }
            }
            for(i=0;i<=2;i++)
            {
                if(ch==special[i])
                {
                    printf("SP");
                    printf(" ");
                }
            }

        }//main while loop

    }
    fclose(fp);
    return 0;
}
