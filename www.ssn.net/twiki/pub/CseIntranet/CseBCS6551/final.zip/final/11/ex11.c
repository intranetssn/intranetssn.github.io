#include<stdio.h>
struct block
{
	char def[30][30];
	int nod;
	int *gen,*kill;
	int *in,*out;
};
int a[30][30],am[30][30];	
struct block *b;
int n,tnod=0,index=0,noe,b1,b2;
int visited[10];

void search(int node,int nodea)
{
	visited[node]=1;	
	a[nodea][node]=1;
	for(int j=0;j<n;j++)
		if(visited[j]==0&&a[node][j]==1)
			search(j,nodea);	
}
 
int main()
{
	printf("Enter number of blocks:");
	scanf("%d",&n);	
	b=malloc(n*sizeof(struct block));			
	
		for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
			a[i][j]=0;
	for(int i=0;i<n;i++)
	{
		printf("Enter number of definitions in Block B%d:",i+1);
		scanf("%d",&b[i].nod);
		printf("Enter the definitions in Block B%d:\n",i+1);
		for(int j=0;j<b[i].nod;j++)
			scanf("%s",b[i].def[j]);
		tnod+=b[i].nod;	
	}
	for(int i=0;i<n;i++)
	{
		b[i].gen=malloc(tnod*sizeof(int));
		b[i].kill=malloc(tnod*sizeof(int));
		b[i].in=malloc(tnod*sizeof(int));
		b[i].out=malloc(tnod*sizeof(int));
		for(int j=0;j<tnod;j++)
			b[i].gen[j]=b[i].kill[j]=0;	
	}
	//Working on GEN
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<b[i].nod;j++)
		{
			b[i].gen[index+j]=1;
		}
		index+=b[i].nod;
				
	}
	//Working on KILL
	printf("Enter number of edges:");
	scanf("%d",&noe);
	for(int i=0;i<noe;i++)
	{
		printf("Enter the Edge %d:",i+1); 	
		scanf("%d%d",&b1,&b2);
		a[b1-1][b2-1]=1;
		am[b1-1][b2-1]=1;
	}						
	//Adjacency Matrix in a
	char temp;
	for(int i=0;i<n;i++)
	{
		//printf("\nReachability from %d:",i+1);
		for(int j=0;j<n;j++)
					visited[j]=0;
			search(i,i);
	}
	for(int i=0;i<n;i++)
	{	
		for(int i1=0;i1<b[i].nod;i1++)
		{
		int nnod=0;
		for(int j=0;j<n;j++)
		{	
			if(a[i][j]==1&&i!=j)
			{
				for(int k=0;k<b[j].nod;k++)
					if(b[j].def[k][0]==b[i].def[i1][0])
						b[i].kill[nnod+k]=1;
						
			}
			
			nnod+=b[j].nod;
		}
		
		}
	}
	//Printing GEN
	printf("\nGEN:\n");
	for(int i=0;i<n;i++)
	{
		printf("\nBLOCK %d:",i+1);
		for(int j=0;j<tnod;j++)
			printf("%d",b[i].gen[j]);
	}
	printf("\nKILL:\n");
	//Printing KILL
	for(int i=0;i<n;i++)
	{
		printf("\nBLOCK %d:",i+1);
		for(int j=0;j<tnod;j++)
			printf("%d",b[i].kill[j]);
	}

	//Initialialize
	
}




