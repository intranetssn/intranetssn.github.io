#include<stdio.h>
struct node{
char val,label[10];
int count;
struct node *l,*r;
};
int main()
{
	char a[30][30];
	int n;
	struct node *l[30];
	int i,j,c=0;	
	printf("Enter number of statements:");
	scanf("%d",&n);
	printf("Enter the TAC statements:");
	for(i=0;i<n;i++)
		scanf("%s",a[i]);
	struct node *o1=malloc(sizeof(struct node));
	o1->val=a[0][2];
	o1->l=o1->r=NULL;
	o1->count=0;
	o1->label[o1->count++]=a[0][2];
	l[c++]=o1;

	struct node *o2=malloc(sizeof(struct node));
	o1->val=a[0][4];
	o2->l=o2->r=NULL;
	l[c++]=o2;
	o2->count=0;
	o2->label[o2->count++]=a[0][4];
	
	struct node *o3=malloc(sizeof(struct node));
	o3->val=a[0][3];
	o3->l=o1;
	o3->r=o2;
	o3->count=0;
	o3->label[o3->count++]=a[0][0];
	l[c++]=o3;
	
	printf("Node %c Created At %ld With Left Child %c with Address:%ld and Right Child %c with Address:%ld\n",o3->val,o3,o3->l->label[0],o3->l,o3->r->label[0],o3->r);		
//	printf("l[0]->label[0]:%c",l[0]->label[0]);
	for(i=1;i<n;i++)
	{
		struct node *o=malloc(sizeof(struct node));
		o->val=a[i][3];
		o->l=o->r=NULL;
		o->count=0;
		o->label[o->count++]=a[i][0];
		l[c++]=o;
		int left=0,right=0,li=-1,ri=-1;
				
		for(j=0;j<c;j++)
		{
			if(l[j]->label[0]==a[i][2])
			{
				
				//printf("Hello Left");
				o->l=l[j];
				left=1;
				li=j;
			}
			if(l[j]->label[0]==a[i][4])
			{

				//printf("Hello Right");
				o->r=l[j];
				right=1;
				ri=j;
			}
		}
		if(!left)
		{
			//Create Left Node
			struct node *o1=malloc(sizeof(struct node));
			o1->val=a[i][2];
			o1->l=o1->r=NULL;
			o1->count=0;
			o1->label[o1->count++]=a[i][2];
			l[c++]=o1;
			o->l=o1;
		}
		if(!right)
		{
			//Create Right Node
			struct node *o1=malloc(sizeof(struct node));
			o1->val=a[i][4];
			o1->l=o1->r=NULL;
			o1->label[o1->count++]=a[i][4];
			o1->count=0;
			l[c++]=o1;
			o->r=o1;
		}
		if(left&&right&&ri==li)
		{
				l[ri]->label[l[ri]->count++]=a[i][3];
				free(o);
				c--;
				
		}
		else
			{
				printf("Node %c Created At %ld With Left Child %c with Address:%ld and Right Child %c with Address:%ld\n",o->val,o,o->l->label[0],o->l,o->r->label[0],o->r);					
			}		
	}
}
