#include<stdio.h>
#include<stdlib.h>
int main()
{
  int i,s;
  char c;
  char Seq[10][10];
  printf("Input :");
  for(i=0;i<2;i++)
    scanf("%s",Seq[i]);
  printf("\nGiven Sequences :");
  for(i=0;i<2;i++)
    printf("\n%s",Seq[i]);

    for(i=0;i<2;i++)
    {
       if((Seq[i][3]=='+') && (Seq[i][2]=='0'|| Seq[i][4]=='0'))
      {     
    if(Seq[i][2]=='0')
      {     
     Seq[i][2]=Seq[i][4];
       Seq[i][3]='\0';
      }
    if(Seq[i][4]=='0')
      {     
     
       Seq[i][3]='\0';
    }
   }   

   if((Seq[i][3]=='-') && (Seq[i][2]=='0'|| Seq[i][4]=='0'))
      {     
    if(Seq[i][2]=='0')
      {     
     Seq[i][2]=Seq[i][4];
       Seq[i][3]='\0';
      }
    if(Seq[i][4]=='0')
      {     
     
       Seq[i][3]='\0';
    }
   }   
}
   printf("\nOptimized Sequences :");
   for(i=0;i<2;i++)
    printf("\n%s",Seq[i]);

}
