#include<stdio.h>
#include<stdlib.h>
int main()
{
  int i,s;
  char c;
  char TAC[10][10];
  printf("Input  :");
  for(i=0;i<2;i++)
    scanf("%s",TAC[i]);
  printf("\nGiven Sequence :");
  for(i=0;i<2;i++)
    printf("\n%s",TAC[i]);

  for(i=0;i<2;i++)
  {
  s=TAC[i][2]-48+TAC[i][4]-48;
  c=s+48;
  TAC[i][2]=c;
  TAC[i][3]='\0';
  }
  printf("\nOptimized Sequence :");
  for(i=0;i<2;i++)
    printf("\n%s",TAC[i]);

}
