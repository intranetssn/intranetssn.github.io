#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct active
{
	int ret,no;	
};

struct active st[100];
int top=0,flag=0,sp=2000;
char fname[100];

void push(struct active tmp)
{
	st[top]=tmp;
	printf("\nENTRY %s function\nreturn address:%d\nno of parameters:%d\n",fname,st[top].ret,st[top].no);
	top++;
	sp+=(sizeof(tmp));
	printf("\nStack pointer address: %d\n",sp);
}

void pop()
{
	top--;
	sp-=(sizeof(st[top]));
}

void disp()
{
	printf("\nEXIT %s function\nreturn address:%d\nno of parameters:%d\n",fname,st[top].ret,st[top].no);
	printf("\nStack pointer address: %d\n",sp);
}


void main()
{
	int i=0,j,n,lineno=100,k;
	char s[1024][1024];
	printf("Enter number of lines in the program: ");
	scanf("%d",&n);
	while(i<=n)
	{
		gets(s[i++]);
	}
	printf("\nInitial stack pointer address: %d\n",sp);
	for(j=1;j<=n;++j,lineno+=20)
	{
		while(flag>0)
		{
			pop();
			disp();
			flag--;
		}
		
		if(strstr(s[j],"(") && strstr(s[j],"="))
		{
			struct active tmp;
			tmp.ret=lineno+20;
			tmp.no=0;
			int pos=0;
			int f=0;
			for(k=0;k<strlen(s[j]);++k)
			{
				if(s[j][k]==',')
					tmp.no++;
				if(s[j][k]=='=')
				{
					while(f==0)
					{
						k++;
						if(s[j][k]=='(')
						{
							f=1;
							break;
						}
						fname[pos++]=s[j][k];
					}
				}
			}
			if(tmp.no!=0)
				tmp.no++;
			push(tmp);
			flag++;
		}
	}
}
